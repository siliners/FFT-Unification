﻿/*
    Author: Thomas Kim
    Date: May 10, 2025
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
    - Share — copy and redistribute the material in any medium or format
    - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
    - Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
      You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others
    from doing anything the license permits.

    For full license text, see:
    https://creativecommons.org/licenses/by/4.0/legalcode
*/

#include <iostream>
#include <complex>
#include <cmath>
#include <numbers>
#include <vector>
#include <tuple>
#include <numeric>
#include <type_traits>
#include <concepts>
#include <algorithm>
#include <array>
#include <chrono>
#include <random>

namespace fft_ifft
{
    using real = double;
    using cplx = std::complex<real>;
    using cplx_numbers = std::vector<cplx>;
   
    inline constexpr auto pi = std::numbers::pi_v<real>;

    enum class scaling_factor { NO_Scaling, FFT_N,
                             IFFT_N, Both_sqrt_N };

    using enum fft_ifft::scaling_factor;

    enum class OmegaMode { fft_mode, ifft_mode };

    template<typename... Types> struct type_container{};

    namespace hidden
    {
        template<typename T> struct
        st_complex: std::false_type { };

        template<typename T> struct
        st_complex< std::complex<T> >: std::true_type { };

        template<typename T> struct
        st_tuple: std::false_type { };

        template<typename... Ts> struct
        st_tuple<std::tuple<Ts...>>: std::true_type { };

        template<typename Type> struct
        st_real_type { using type = Type; };

        template<typename Type> struct
        st_real_type<std::complex<Type>> { using type = Type; };
    }
    // end of namespace hidden

    template<typename T>
    concept complex_c = 
        hidden::st_complex<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept real_c = std::floating_point<std::remove_cvref_t<T>>;

    template<typename T>
    concept real_or_cplx_c = real_c<T> || complex_c<T>;

    template<typename T>
    using real_type_t = 
        typename hidden::st_real_type< std::remove_cvref_t<T> >::type;
    
    template<typename T>
    concept tuple_c = 
        hidden::st_tuple<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept number_c = 
        std::integral<std::remove_cvref_t<T>> || 
        std::floating_point<std::remove_cvref_t<T>> ||
        complex_c<std::remove_cvref_t<T>>;

    template<typename T>
    concept non_number_c = !number_c<T>;

    // the reason MaxInvocableCount is set to 17
    // is that from my experiment with various C++ compiler,
    // Microsoft C++ compiler did now work in stable mode
    // when the function parameter count is over 16 or 17.
    // this value can be changed as Microsoft C++ compiler's
    // capability improves in the future.
    inline constexpr int MaxInvocableCount = 17;

    template<auto val>
    concept param_c = (val > 0) && (val < MaxInvocableCount);

    namespace hidden
    {
        template<non_number_c FuncType, number_c ArgType, number_c... ArgTypes>
        constexpr int fn_param_count() noexcept
        {
            if constexpr(std::invocable<FuncType, ArgType, ArgTypes...>)
                return sizeof...(ArgTypes) + 1;
            else if constexpr( (sizeof...(ArgTypes) + 1) < MaxInvocableCount )
                return fn_param_count<FuncType, ArgType, ArgType, ArgTypes...>();
            else 
                return MaxInvocableCount;
        }

        template<number_c FuncType, number_c ArgType, number_c... ArgTypes>
        constexpr int fn_param_count() noexcept
        {
            return 0;
        }

        template<typename FuncType>
        struct st_numerical_function
        {
            static constexpr bool value = false;
        };

        template<non_number_c FuncType>
        struct st_numerical_function<FuncType>
        {
            static constexpr bool value = 
                (fn_param_count<FuncType, int>() != MaxInvocableCount) || 
                (fn_param_count<FuncType, double>() != MaxInvocableCount) ||
                (fn_param_count<FuncType, std::complex<float>>() != MaxInvocableCount) || 
                (fn_param_count<FuncType, std::complex<double>>() != MaxInvocableCount);
        };

        template<non_number_c FuncType, number_c ArgType = float>
        constexpr int parameter_count_v = 
              fn_param_count<std::remove_cvref_t<FuncType>,
                    std::remove_cvref_t<ArgType>>();
    }
    // end of namespace hidden

    template<non_number_c FuncType, number_c ArgType = float>
        constexpr int parameter_count_v = 
                hidden::parameter_count_v<FuncType, ArgType>;

    template<typename FuncType, typename ArgType = double>
    concept function_c = param_c<parameter_count_v<FuncType, ArgType>>;

    template<number_c Type>
    Type adjust_zero(Type v)
    {
        if constexpr (std::integral<Type>)
            return v;
        else if constexpr(std::floating_point<Type>)
        {
            auto epsilon = 100000 *
                std::numeric_limits<Type>::epsilon();

            return (std::abs(v) >epsilon) ? v : (Type)0;
        }
        else if constexpr(complex_c<Type>)
        {
            return { adjust_zero(v.real()), adjust_zero(v.imag()) };
        }
    }

    template<number_c T> std::vector<T>
    adjust_zero(std::vector<T> vctr)
    {
        for(auto& e: vctr)
            e = adjust_zero(e);

        return vctr;
    }
   
    template<typename... Types> std::tuple<Types...>
    adjust_zero(std::tuple<Types...> const& tpl)
    {
        constexpr int N = sizeof...(Types);

        auto adjust = [&]<typename T>(T const& ele)
        {
            // if ele itself is of tuple
            // then adjust_zero(ele) is recursive called
            // otherwise previously overloaded adjust_zero is called
            return adjust_zero(ele);
        };

        return [&]<typename T, T...ns>
            (std::integer_sequence<T, ns...>)
        {
            return std::tuple{ adjust(std::get<ns>(tpl)) ... };

        }(std::make_integer_sequence<int, N>{});
    }
    
    template<tuple_c T> std::vector<T>
    adjust_zero(std::vector<T> vctr)
    {
        for(auto& e: vctr) e = adjust_zero(e);
        return vctr;
    }
    
    // this forwared declaration is required for recursive call
    template<typename... Types>std::ostream& operator<<
        (std::ostream& os, std::tuple<Types...> const& tple);

    template<typename Type> std::ostream& operator<<
    (std::ostream& os, std::vector<Type> const& vctr)
    {
        if(vctr.empty())
        {
            os << "{ }"; return os;
        }
        else
        {
            os << "{ ";

            int N = vctr.size() - 1;

            for(int n = 0; n < N; ++n)
                // recursive
                os << adjust_zero(vctr[n]) <<", ";
            
            // recursive
            os << adjust_zero(vctr.back()) << " }";
            
            return os;
        }
    }

    template<typename... Types>std::ostream& operator<<
        (std::ostream& os, std::tuple<Types...> const& tple)
    {   

        constexpr int N = sizeof...(Types);

        auto tpl = adjust_zero(tple);

        if constexpr(N == 0)
        {
            os << "[ ]"; return os;
        }
        else if constexpr(N == 1)
        {
            // this block is base case

            using ele_t = std::tuple_element_t<0, std::tuple<Types...>>;
            
            if constexpr( tuple_c<ele_t> )
            {
                // recursive
                os << "[ " << std::get<0>(tpl) << " ]";
                return os;
            }
            else
            {
                // non-recursive
                os << "[ " << adjust_zero(std::get<0>(tpl)) << " ]";
                return os;
            }
        }
        else
        {
            os<<"[ ";

            auto print = [&](auto& arg)
            {
                // if args is of type tuple,
                // then this call is recursive
                os << adjust_zero(arg) <<", ";
            };

            [&]<typename T, T...ns>
                (std::integer_sequence<T, ns...>)
            {
                ( print(std::get<ns>(tpl)), ...);

            }(std::make_integer_sequence<int, N-1>{});

            // if args is of type tuple,
            // then this call is recursive
            os << adjust_zero(std::get<N-1>(tpl)) <<" ]";

            return os;
        }
    }

    // this forwared declaration is required for recursive call
    template<typename... Types>std::ostream& operator<<
        (std::ostream& os, std::tuple<Types...> const& tple);

    template<typename Type, std::size_t M> std::ostream& operator<<
    (std::ostream& os, std::array<Type, M> const& vctr)
    {
        if(M == 0)
        {
            os << "( )"; return os;
        }
        else
        {
            os << "(";

            int N = vctr.size() - 1;

            for(int n = 0; n < N; ++n)
                // recursive
                os << adjust_zero(vctr[n]) <<", ";
            
            // recursive
            os << adjust_zero(vctr.back()) << ")";
            
            return os;
        }
    }

    // return [p, n, p^n, p^n*n ]
    // where p^n, N <= p^n, p^n * n 
    inline std::tuple<long long, long long, long long, long long> 
        get_optimal_radix(int N, int MaxRadix = 8) 
    {
        long long min_cost = 
            std::numeric_limits<long long>::max();

        long long best_p = -1;
        long long best_n = -1;
        long long best_M = -1;

        for (long long p = 2; p < MaxRadix; ++p) 
        {
            long long n = 1;
            long long power = p;
            
            while (power < N) 
            {
                power *= p; ++n;
            }

            // power = p^n,
            // N <= p^n 
            // cost = p^n * n
            long long cost = power * n;
            
            if (cost < min_cost) 
            {
                min_cost = cost;
                
                best_p = p; best_n = n;

                best_M = power;
            }
        }

        return {best_p, best_n, best_M, min_cost};
    }
    
    template<typename = void>
    int reverse_base_s(int idx, int s, int num_digits)
    {
        int reversed = 0;
        for (int i = 0; i < num_digits; ++i)
        {
            reversed = reversed * s + (idx % s);
            idx /= s;
        }
        return reversed;
    }

    template<typename CplxType> std::tuple<int, int> 
    reorder_coefficients(std::vector<CplxType>& data)
    {
        int N = data.size(); // N = 1, 2, 3,
                             // N = s^n, s = 2, 3, 4, ...
                             // n = 0, 1, 2, 3

        int MaxRadix = (int)std::ceil(N);

        // N <= sn = s^numBits, snn = s^numBits * n = maximum computation
        // s is radix of the FFT or IFFT
        auto [s, numBits, sn, snn] = 
            get_optimal_radix(N, MaxRadix );

        
        // std::cout <<"*** Auto selected optimal radix s <= MaxRadix(" 
        //     << MaxRadix <<") is "<< s << ", n = numBits = " 
        //     << numBits <<".\n"<< std::endl;

        // std::cout <<"*** Time complexity = "<< sn << " x log_"<< s 
        //     << "(" <<sn<<") = " << (sn * std::log(sn) / std::log(s) ) 
        //     << std::endl << std::endl; 
        
        // if(sn - N > 0)
        //     std::cout <<"*** s^n("<<sn<<") - N("<<N<<") = " << (sn - N) 
        //         << " trailing zero's should be padded as in below."
        //         << std::endl << std::endl;
        // else
        //     std::cout <<"*** s^n("<<sn<<") - N("<<N<<") = " << (sn - N) 
        //         << ". No padding is required."<< std::endl<< std::endl;
        
        if(s == N)
        {
            // std::cout <<"*** No suffling At ALL!!\n" << std::endl;
        }
        else // no shffling at all when s == N
        {
            // std::cout << "*** Suffling occurred.\n" << std::endl;

            // automatic resizing occurs only when s^n > N
            if ( sn > N)
            {
                // std::cout <<"*** Automatic resizing occurred when s^n("
                //     << sn <<") > N(" << N << ")."<< std::endl << std::endl ; 

                data.resize(sn); 
            }

            for(int x = 0; x < N; ++x)
            {
                int reverse_index = reverse_base_s(x, s, numBits);

                if(reverse_index > x)
                {
                    std::swap(data[x], data[reverse_index]);
                }
            }
        }
              
        return {(int)s, (int)numBits};
    }

    template<typename CplxType>
    void fft_gen(std::vector<CplxType>& coeffs, bool positive = true)
    {
        constexpr auto pi = std::numbers::pi_v<double>;

        if(coeffs.size() < 2)
            return;
        else if(coeffs.size() == 2)
        {
            auto even = coeffs.front();
            auto odd = coeffs.back();

            coeffs[0] = even + odd;
            coeffs[1] = even - odd;

            return;
        }
       
        // no shuffling at all when N is
        // less than <= MaxRadix by algorithm design
        auto [s, numBits] = reorder_coefficients(coeffs);
        
        int N = coeffs.size();

        // if(positive == true)
        //     std::cout << "->coeffs in IFFT = ";
        // else
        //     std::cout << "->coeffs in FFT  = ";
        
        // std::cout << coeffs << std::endl;

        auto omega = [N, positive](auto k)
        {
            return std::exp( CplxType{ 0.0,
                positive ? 2.0 * pi * k / N : -2.0 * pi * k / N } );
        };

        // when s == N, it iterates only once
        for(int len = s; len <= N; len *= s ) 
        {
            // when s == N, len == s, it iterates only once
            for(int i = 0;  i < N; i += len) 
            {
                // when s == N, len == s, it iterates only once
                for(int j = 0; j < len/s; ++j)
                {
                    std::vector<CplxType> bin_ele(s);

                    // when s == N, len == s
                    // i + j = 0, len/s = 1, 
                    // simply copies elements from coeffs to bin_ele
                    for(int bin = 0; bin < s; ++bin)
                    {
                        bin_ele[bin] = coeffs[len/s * bin + i+j];
                    }
                    
                    // when s == N, len == s, it iterates s(=N)
                    for(int bin = 0; bin < s; ++bin)
                    {
                        coeffs[len/s * bin + i+j] = [&]
                            {
                                CplxType sum{};
                                                            
                                // when s == N, len == s, it iterates s(=N) times
                                for(int k = 0; k < s; ++k)
                                {
                                    sum += omega(( j * (N/len) + N/s * bin) * k )
                                            * bin_ele[k];
                                }
                                
                                return sum;
                            }();
                    }
                }
            }
        }
    }
    // end of function fft_gen()

    template<typename CplxType>
    auto ifft_gen(std::vector<CplxType> const& coeffs)
    {
        auto fvs = fft_gen(coeffs, false);
        int N = fvs.size();

        for(int k = 0; k < N ; ++k)
            fvs[k] /= (double)N;

        return fvs;
    }
    // end of function ifft_gen()

    template<scaling_factor factor>
    auto get_gen_fft()
    {
        if constexpr(factor == scaling_factor::NO_Scaling)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::FFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, false); // e^-2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::IFFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, true); // e^2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
        else // factor == scaling_factor::Both_sqrt_N
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, false); // e^-2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;

            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_gen(coeffs, true); // e^2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
    }
    // end of get_gen_fft()

    //////////////////////////////////////////////////
    template<typename CplxType>
    void fft_simple(std::vector<CplxType>& coeffs, bool positive = true)
    {
        constexpr auto pi = std::numbers::pi_v<double>;

        using T = typename CplxType::value_type;

        int N = coeffs.size();

        if(N < 2) return;

        auto coe = coeffs;

        auto omega = [N, positive](auto n, auto k)
        {
            return std::exp( CplxType{(T)0, positive == true ?
                    2.0 * pi * n * k / N : -2.0 * pi * n * k / N } );
        };

        for(int n = 0; n < N; ++n )
        {
            CplxType sum{};

            for(int k = 0; k < N; ++k)
            {
                sum += coe[k] * omega(n, k);
            }

            coeffs[n] = sum;
        }
    }
    // end of function fft_simple()

    template<typename CplxType>
    auto ifft_simple(std::vector<CplxType> const& coeffs)
    {
        auto fvs = fft_simple(coeffs, false);
        int N = fvs.size();

        for(int k = 0; k < N ; ++k)
            fvs[k] /= (double)N;

        return fvs;
    }

    template<scaling_factor factor>
    auto get_simple_fft()
    {
        if constexpr(factor == scaling_factor::NO_Scaling)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::FFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, false); // e^-2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::IFFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, true); // e^2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
        else // factor == scaling_factor::Both_sqrt_N
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, false); // e^-2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;

            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_simple(coeffs, true); // e^2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
    }
    // end of get_gen_fft()

    // we are compute Order order of derivative of f
    // w.r.t VarID-th variable
    template<int VarID, int Order, int N = 16, typename FuncType,
        int params = parameter_count_v<FuncType>>
        requires param_c<params>
    auto fft_derivative(FuncType f)
    {
        return [f]<real_or_cplx_c ArgType, real_or_cplx_c... ArgTypes>
            (ArgType x, ArgTypes... xs) requires( sizeof...(xs) + 1 == params)
        {
            using real_t =  real_type_t<ArgType>;
            using cplx_t = std::complex<real_t>;
        
            auto args = [=]()
                {
                    if constexpr( real_c<ArgType> )
                        return std::tuple{ cplx_t{ x, (real_t)0 }, cplx_t{ xs, (real_t)0 } ... };
                    else
                        return std::tuple{ x, xs... };
                }();
                       
            std::vector<cplx_t> fv(N);

            // this w is for sampling function values
            auto w = [center = std::get<VarID>(args) ](int n)
            {
                constexpr auto pi = std::numbers::pi_v<real_t>;

                return center + std::exp(std::complex<real_t>{ 0.0, 2 * pi * n / N}); 
            };

            auto omega = [](int n)
            {
                constexpr auto pi = std::numbers::pi_v<real_t>;
                return std::exp(cplx_t{ 0.0, -2 * pi * Order * n / N}); 
            };

            // all we need is Order-th coefficient of f
            cplx_t coeff{};

            // THIS PART OF CODE WILL BE ABSTRACTED AWAY
            // TO HANDLE MORE ADVANCED CASES, SUCH AS LAURENT SERIES
            // the Time Complexity is N
            for(int n = 0; n < N; ++n)
            {
                // update VarID-th parameter 
                std::get<VarID>(args) = w(n);

                // the reason we have to divide f(w) by N
                // is we are goind to call fft to evaluate coefficients
                // our sampling should match ifft's scaling factor
                fv[n] = std::apply(f, args) / (real_t)N;
                coeff += omega(n) * fv[n];
            }

            // 𝑓⁽ⁿ⁾ = 𝑐 ⋅ 𝑛!
            // IMPORTANT: the following is bug
            // return coeff.real() * std::tgamma(Order + (real_t)1);
            return coeff * std::tgamma(Order + (real_t)1);
        };
    }

    template<int VarID, int Order = 1, int N = 32>
    struct derivative_command{ };

    template<int VarID, int Order = 1, int N = 32>
    inline constexpr auto drv = derivative_command<VarID, Order, N>{};

    template<int VarID, int Order, int N, typename... Types, function_c FuncType> auto 
    operator*(derivative_command<VarID, Order, N>, FuncType&& f)
    {
        return [f]<real_or_cplx_c ArgType, real_or_cplx_c... ArgTypes>
                (ArgType arg, ArgTypes... args)
            requires ( sizeof...(ArgTypes) + 1 == parameter_count_v<FuncType>)
        { 
            if constexpr(real_c<ArgType>)
                return std::real( fft_derivative<VarID, Order, N>(f)(arg, args...) );
            else 
                return std::real( fft_derivative<VarID, Order, N>(f)(arg, args...) );
        };
    }

    template<int VarID1, int Order1, int N1, int VarID2, int Order2, int N2>
    constexpr type_container<derivative_command<VarID2, Order2, N2>, derivative_command<VarID1, Order1, N1> >
    operator*(derivative_command<VarID1, Order1, N1>, derivative_command<VarID2, Order2, N2>)
    { return{ }; }

    template<typename... Types, int VarID, int Order, int N>
    constexpr type_container<derivative_command<VarID, Order, N>, Types...>
    operator*(type_container<Types...>, derivative_command<VarID, Order, N>)
    {   return{ }; }

    template<int VarID, int Order, int N, typename... Types, function_c FuncType> auto 
    operator*(type_container< derivative_command<VarID, Order, N>, Types...>, FuncType&& f)
    {
        if constexpr(sizeof...(Types) == 0)
        {
            // operator*(derivative_command<VarID, Order, N>, FuncType&& f) is called
            return derivative_command<VarID, Order, N>{} * f;
        }
        else
        {
            // recursion 
            return type_container<Types...>{} * fft_derivative<VarID, Order, N>(f);
        }
    }
}
// end of namespace fft_ifft