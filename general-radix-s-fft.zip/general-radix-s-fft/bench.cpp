﻿/*
    Author: Thomas Kim
    Date: May 11, 2025
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
    - Share — copy and redistribute the material in any medium or format
    - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
    - Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
      You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others
    from doing anything the license permits.

    For full license text, see:
    https://creativecommons.org/licenses/by/4.0/legalcode

    icx-cl /O2 /QxAVX2 /Qipo /std:c++20 /EHsc bench.cpp -o i.exe
    cl /O2 /arch:AVX2 /Ob3 /GL /std:c++20 bench.cpp /Fe: m.exe
    g++ -O3 -mavx2 -mfma -march=native -std=c++20 -ltbb12 bench.cpp -ltbb12 -o g.exe
    clang++ -O3 -mavx2 -mfma -march=native -std=c++20 bench.cpp -ltbb12 -o c.exe
*/
#include <cpg/cpg_library.hpp>

#include "radix-s-fft.hpp"
using namespace fft_ifft;

using namespace std;
using namespace std::chrono;

using real_t = double;
using complex_t = complex<real_t>;

vector<complex_t> generate_random_signal(size_t N) 
{
    mt19937 rng(42);
    
    uniform_real_distribution<real_t> dist(-1.0, 1.0);
    
    vector<complex_t> signal(N);
    
    for (auto& x : signal)
        x = complex_t(dist(rng), dist(rng));
    
        return signal;
}

void benchmark_fft_simple(size_t N) 
{
    Cpg_DisplayFunctionName();

    auto [fft, ifft] = get_simple_fft<IFFT_N>();

    auto input = generate_random_signal(N);
    
    vector<complex_t> output(N);

    auto start = high_resolution_clock::now();

    fft(input); // Replace with your FFT function
    
    auto end = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(end - start).count();
    
    cout << "N = " << N << ", Time: " << duration << " us" << endl;
}

void benchmark_fft_gen(size_t N) 
{
    Cpg_DisplayFunctionName();

    auto [fft, ifft] = get_gen_fft<IFFT_N>();

    auto input = generate_random_signal(N);
    
    vector<complex_t> output(N);

    auto start = high_resolution_clock::now();

    fft(input); // Replace with your FFT function
    
    auto end = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(end - start).count();
    
    cout << "N = " << N << ", Time: " << duration << " us" << endl;
}

int main() 
{
    // vector<size_t> sizes = {16, 64, 256, 1024, 4096, 16384, 65536};
    vector<size_t> sizes = {16, 64, 256, 1024, 4096, 16384};
    
    for (auto N : sizes) 
    {
        benchmark_fft_simple(N);
    }

    for (auto N : sizes) 
    {
        benchmark_fft_gen(N);
    }

    return 0;
}



