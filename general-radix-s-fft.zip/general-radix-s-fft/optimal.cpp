﻿#include <iostream>
#include <vector>
#include <limits>
#include <tuple>
#include <cmath>
#include <array>

// return [p, n, p^n, p^n*n ]
// where p^n, N <= p^n, p^n * n 
std::tuple<long long, long long, long long, long long> 
    find_optimal_radix(int N, int MaxRadix = 64) 
{
    long long min_cost = 
        std::numeric_limits<long long>::max();

    long long best_p = -1;
    long long best_n = -1;
    long long best_M = -1;

    for (long long p = 2; p <= MaxRadix; ++p) 
    {
        long long n = 1;
        long long power = p;
        
        while (power < N) 
        {
            power *= p; ++n;
        }

        // power = p^n,  N <= p^n 
        // cost = p^n * n
        long long cost = power * n;
        
        if (cost < min_cost) 
        {
            min_cost = cost;
            
            best_p = p; best_n = n;

            best_M = power;
        }
    }

    return {best_p, best_n, best_M, min_cost};
}

auto log_n(auto n, auto x)
{
    return std::log(x)/std::log(n);
}

// Example usage
int main() 
{
    long long N = 6 * 6;
    
    std::cout <<"N = " << N 
        << std::endl<< std::endl;

    auto [p, n, M, cost] = find_optimal_radix(N, 8);
    std::cout << "Best radix: p = " << p << ", n = " << n << "\n";
    std::cout << "Padded size M = " << M << ", Cost = " 
        << cost << "\n\n";

    auto N2 = N * N;

    auto P = std::pow(p, n);
    std::cout << "std::pow(p, n) = " << P 
        << std::endl<< std::endl;

    auto P2 = P * n;
    auto MR = N * log_n(6, N); // optimized Mixed Radix-6 FFT

    std::cout << "Wrost         N2 = " << N2 << std::endl;
    std::cout << "Discovery     P2 = " << P2 << std::endl;
    std::cout << "Mixed Radix-6 MR = " << MR 
        << std::endl<< std::endl;

    std::cout <<"N2/P2 = " << N2 / (double)P2 << std::endl;
    std::cout <<"N2/MR = " << N2 / (double)MR << std::endl;
    std::cout <<"MR/P2 = " << MR / (double)P2 << std::endl;

    return 0;
}
