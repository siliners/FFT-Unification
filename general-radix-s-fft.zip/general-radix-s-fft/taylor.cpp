﻿// Cantor's first set theory article
// https://en.wikipedia.org/wiki/Cantor%27s_first_set_theory_article

// Isaac Newton
// https://en.wikipedia.org/wiki/Isaac_Newton

// Philosophiæ Naturalis Principia Mathematica
// https://en.wikipedia.org/wiki/Philosophi%C3%A6_Naturalis_Principia_Mathematica

// Limit of a function
// https://en.wikipedia.org/wiki/Limit_of_a_function
// 

#include "fft-tools.hpp"

using namespace fft_ifft;

void test_standard_sampling_IFFT_N()
{
    DisplayFunctionName();

    int precision = 17;

    std::cout.precision(precision);
    std::cout <<"Precision: " << precision << std::endl << std::endl;
    
    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, fft, ifft] = 
            get_taylor_sampler<standard_sampling, IFFT_N>();

    auto f_sin = [](auto z)
    {
        return std::sin(z);
    };

    auto f_cos = [](auto z)
    {
        return std::cos(z);
    };

    int N = 16;

    auto fv_sin = sampler(f_sin, N);
    auto fv_cos = sampler(f_cos, N);

    std::cout << "Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    

    fft(fv_sin); fft(fv_cos);

    std::cout << "Taylor expansion for sin(x) = \n\t" 
        << cplx_to_double(fv_sin) << std::endl << std::endl;

    std::cout << "Taylor expansion for cos(x) = \n\t" 
        << cplx_to_double(fv_cos) << std::endl << std::endl;    

    ifft(fv_sin); ifft(fv_cos);

    std::cout << "Reconstructed Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Reconstructed Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    
}

void test_standard_sampling_FFT_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, fft, ifft] = 
            get_taylor_sampler<standard_sampling, FFT_N>();

    auto f_sin = [](auto z)
    {
        return std::sin(z);
    };

    auto f_cos = [](auto z)
    {
        return std::cos(z);
    };

    int N = 16;

    auto fv_sin = sampler(f_sin, N);
    auto fv_cos = sampler(f_cos, N);

    std::cout << "Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    

    fft(fv_sin); fft(fv_cos);

    std::cout << "Taylor expansion for sin(x) = \n\t" 
        << cplx_to_double(fv_sin) << std::endl << std::endl;

    std::cout << "Taylor expansion for cos(x) = \n\t" 
        << cplx_to_double(fv_cos) << std::endl << std::endl;    

    ifft(fv_sin); ifft(fv_cos);

    std::cout << "Reconstructed Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Reconstructed Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    
}

void test_standard_sampling_Both_sqrt_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, fft, ifft] = 
            get_taylor_sampler<standard_sampling, Both_sqrt_N>();

    auto f_sin = [](auto z)
    {
        return std::sin(z);
    };

    auto f_cos = [](auto z)
    {
        return std::cos(z);
    };

    int N = 16;

    auto fv_sin = sampler(f_sin, N);
    auto fv_cos = sampler(f_cos, N);

    std::cout << "Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    

    fft(fv_sin); fft(fv_cos);

    std::cout << "Taylor expansion for sin(x) = \n\t" 
        << cplx_to_double(fv_sin) << std::endl << std::endl;

    std::cout << "Taylor expansion for cos(x) = \n\t" 
        << cplx_to_double(fv_cos) << std::endl << std::endl;    

    ifft(fv_sin); ifft(fv_cos);

    std::cout << "Reconstructed Sampling for sin(x) = \n\t" 
        << fv_sin << std::endl << std::endl;

    std::cout << "Reconstructed Sampling for cos(x) = \n\t" 
        << fv_cos << std::endl << std::endl;    
}

void test_standard_rotated_sampling_IFFT_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_sampling, IFFT_N>();

    auto f = [](auto x)
    {
        return (1.0 - x) * (2.0 - x) * (3.0 - x)
            / (1.0 - x);
    };

    int N = 16;

    auto fv = sampler(f, N);
    
    std::cout << "Sampling for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;

    fft(fv);

    auto an = reconstructor(fv);

    std::cout << "Taylor coefficients for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << cplx_to_double(an) << std::endl << std::endl;

    ifft(fv);

    std::cout << "Reconstructed for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;
}

void test_standard_rotated_sampling_FFT_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_sampling, FFT_N>();

    auto f = [](auto x)
    {
        return (1.0 - x) * (2.0 - x) * (3.0 - x)
            / (1.0 - x);
    };

    int N = 16;

    auto fv = sampler(f, N);
    
    std::cout << "Sampling for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;

    fft(fv);

    auto an = reconstructor(fv);

    std::cout << "Taylor coefficients for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << cplx_to_double(an) << std::endl << std::endl;

    ifft(fv);

    std::cout << "Reconstructed for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;
}

void test_standard_rotated_sampling_Both_sqrt_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_sampling, FFT_N>();

    auto f = [](auto x)
    {
        return (1.0 - x) * (2.0 - x) * (3.0 - x)
            / (1.0 - x);
    };

    int N = 16;

    auto fv = sampler(f, N);
    
    std::cout << "Sampling for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;

    fft(fv);

    auto an = reconstructor(fv);

    std::cout << "Taylor coefficients for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << cplx_to_double(an) << std::endl << std::endl;

    ifft(fv);

    std::cout << "Reconstructed for (1 - x)(2 - x)(3 - x) / (1 - x) = \n\t" 
        << fv << std::endl << std::endl;
}

void test_standard_rotated_half_N_sampling_IFFT_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_half_N_sampling, IFFT_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    auto fv_minus = sampler(f_minus, N);
    auto fv_plus = sampler(f_plus, N);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus);
    auto an_plus = reconstructor(fv_plus);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_rotated_half_N_sampling_FFT_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_half_N_sampling, FFT_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    auto fv_minus = sampler(f_minus, N);
    auto fv_plus = sampler(f_plus, N);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus);
    auto an_plus = reconstructor(fv_plus);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_rotated_half_N_sampling_Both_sqrt_N()
{
    DisplayFunctionName();

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<rotated_half_N_sampling, Both_sqrt_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    auto fv_minus = sampler(f_minus, N);
    auto fv_plus = sampler(f_plus, N);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus);
    auto an_plus = reconstructor(fv_plus);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_x_1_IFFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling_x_1, IFFT_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_x_1_FFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling_x_1, FFT_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_x_1_Both_sqrt_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling_x_1, Both_sqrt_N>();

    auto f_minus = [](auto x)
    {
        return 1.0 / (1.0 - x);
    };
    
    auto f_plus = [](auto x)
    {
        return 1.0 / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for 1/(1 - x) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for 1/(1 + x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 1/(1 - x) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for 1/(1 + x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_IFFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling, IFFT_N>();

    auto f_minus = [](auto x)
    {
        return 2.0 * (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x) *(2.0 - x) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);

    std::cout <<"radius = " << radius << std::endl<< std::endl;

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for 2(1-x)(1-x)(2-x)(3-x)/((1-x)(2-x))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for 2(1-x)(1-x)(2-x)(3-x)/((1-x)(2-x)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for 2(1-x)(1-x)(2-x)(3-x)/((1-x)(2-x)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_FFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling, FFT_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/3.0);

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_sampling_Both_sqrt_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_sampling, Both_sqrt_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/3.0);

    auto fv_minus = sampler(f_minus, N, radius);
    auto fv_plus = sampler(f_plus, N, radius);
    
    std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius);
    auto an_plus  = reconstructor(fv_plus, radius);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_radius_rotated_sampling_IFFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_rotated_sampling, IFFT_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto theta = 0.0;

    auto fv_minus = sampler(f_minus, N, radius, theta);
    auto fv_plus = sampler(f_plus, N, radius, theta);
    
    // std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
    //     << fv_minus << std::endl << std::endl;
    
    // std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
    //     << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius, theta);
    auto an_plus  = reconstructor(fv_plus, radius, theta);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    // ifft(fv_minus); ifft(fv_plus);

    // std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
    //     << fv_minus << std::endl << std::endl;

    // std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
    //     << fv_plus << std::endl << std::endl;
}

void test_standard_radius_rotated_sampling_FFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_rotated_sampling, FFT_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto theta = 0.0;

    auto fv_minus = sampler(f_minus, N, radius, theta);
    auto fv_plus = sampler(f_plus, N, radius, theta);
    
    // std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
    //     << fv_minus << std::endl << std::endl;
    
    // std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
    //     << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius, theta);
    auto an_plus  = reconstructor(fv_plus, radius, theta);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    // std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
    //     << fv_minus << std::endl << std::endl;

    // std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
    //     << fv_plus << std::endl << std::endl;
}

void test_standard_radius_rotated_sampling_Both_sqrt_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<radius_rotated_sampling, Both_sqrt_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 8;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto theta = 0.0;

    auto fv_minus = sampler(f_minus, N, radius, theta);
    auto fv_plus = sampler(f_plus, N, radius, theta);
    
    // std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
    //     << fv_minus << std::endl << std::endl;
    
    // std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
    //     << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, radius, theta);
    auto an_plus  = reconstructor(fv_plus, radius, theta);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    // ifft(fv_minus); ifft(fv_plus);

    // std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
    //     << fv_minus << std::endl << std::endl;

    // std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
    //     << fv_plus << std::endl << std::endl;
}

void test_standard_complex_scaled_IFFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<complex_scaled_sampling, IFFT_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto angle = pi/3;

    auto c = std::polar(radius, angle);
    
    auto fv_minus = sampler(f_minus, N, c);
    auto fv_plus = sampler(f_plus, N, c);
    
    std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, c);
    auto an_plus  = reconstructor(fv_plus, c);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_complex_scaled_FFT_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<complex_scaled_sampling, FFT_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto angle = pi/3;

    auto c = std::polar(radius, angle);
    
    auto fv_minus = sampler(f_minus, N, c);
    auto fv_plus = sampler(f_plus, N, c);
    
    std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, c);
    auto an_plus  = reconstructor(fv_plus, c);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_standard_complex_scaled_Both_sqrt_N()
{
    DisplayFunctionName();

    int precision = 17;
    std::cout.precision(precision);

    std::cout << "Precision: " << precision 
        << std::endl << std::endl;

    using enum sampling_method;
    using enum scaling_factor;

    auto [sampler, reconstructor, fft, ifft] = 
            get_taylor_sampler<complex_scaled_sampling, Both_sqrt_N>();

    auto f_minus = [](auto x)
    {
        return (1.0 - x)*(1.0 - x)* (2.0 - x) * (3.0 - x) / ( (1.0 - x)*(x - 2.0) );
    };
    
    auto f_plus = [](auto x)
    {
        return (1.0 + x) * (2.0 + x) * (3.0 - x) * (1.0 - x) / (1.0 + x);
    };

    int N = 16;

    constexpr auto epsilon = 
        std::numeric_limits<double>::epsilon();

    auto radius = (1/2.0);
    auto angle = pi/3;

    auto c = std::polar(radius, angle);
    
    auto fv_minus = sampler(f_minus, N, c);
    auto fv_plus = sampler(f_plus, N, c);
    
    std::cout << "Sampling for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2))= \n\t" 
        << fv_minus << std::endl << std::endl;
    
    std::cout << "Sampling for (1+x)(2+x)(3-x)(1-x)/(1+x); = \n\t" 
        << fv_plus << std::endl << std::endl;

    fft(fv_minus); fft(fv_plus);

    auto an_minus = reconstructor(fv_minus, c);
    auto an_plus  = reconstructor(fv_plus, c);

    std::cout << "Taylor expansion for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << cplx_to_double(an_minus) << std::endl << std::endl;

    std::cout << "Taylor expansion for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << cplx_to_double(an_plus) << std::endl << std::endl;

    ifft(fv_minus); ifft(fv_plus);

    std::cout << "Reconstructed for (1-x)(1-x)(2-x)(3-x)/((1-x)(x-2)) = \n\t" 
        << fv_minus << std::endl << std::endl;

    std::cout << "Reconstructed for (1+x)(2+x)(3-x)(1-x)/(1+x) = \n\t" 
        << fv_plus << std::endl << std::endl;
}

void test_log_x_IFFT_N()
{
 
    int precision = 17;

    std::cout.precision(precision);

    using enum scaling_factor;

    auto [fft, ifft] = get_fft_ifft<IFFT_N>();

    int N = 1024;

    std::cout <<"Precision: " << precision 
        <<", Count of sampling points N: " 
        << N << std::endl << std::endl;
 
    auto f_log_x = [](auto x)
    {
        return std::log(x);
    };

    auto f_log_shift = [f_log_x](auto x)
    {
        // log(x) = (x-1) - (1/2)(x-1)^2 + (1/3)(x-1)^3
        // log(x + 1.0) = x - (1/2)x^2 + (1/3)x^3
        return f(x+1.0);
    };

    // N-th roots of unity, center+e^(2 pi i k / N)
    auto w = [N](auto n)
    {
        return std::exp( cplx{ 0.0, 2 * pi * n / N } );
    };
        
    std::vector<cplx> fn_log_x(N);

    for(int n = 0; n < N; ++n)
    {
        fn_log_x[n] = f_log_x( w(n) ) / (double)(N);
    }

    fft(fn_log_x);

    std::cout <<"log(x) = ... + an (x-1)^n + ... =\n\t" 
        << cplx_to_double(fn_log_x) << std::endl;
}

int main()
{
    test_standard_sampling_IFFT_N();
    test_standard_sampling_FFT_N();
    test_standard_sampling_Both_sqrt_N();

    test_standard_rotated_sampling_IFFT_N();
    test_standard_rotated_sampling_FFT_N();
    test_standard_rotated_sampling_Both_sqrt_N();

    test_standard_rotated_half_N_sampling_IFFT_N();
    test_standard_rotated_half_N_sampling_FFT_N();
    test_standard_rotated_half_N_sampling_Both_sqrt_N();

    test_standard_radius_sampling_x_1_IFFT_N();
    test_standard_radius_sampling_x_1_FFT_N();
    test_standard_radius_sampling_x_1_Both_sqrt_N();

    test_standard_radius_sampling_IFFT_N();
    test_standard_radius_sampling_FFT_N();
    test_standard_radius_sampling_Both_sqrt_N();

    test_standard_radius_rotated_sampling_IFFT_N();
    test_standard_radius_rotated_sampling_FFT_N();
    test_standard_radius_rotated_sampling_Both_sqrt_N();

    test_standard_complex_scaled_IFFT_N();
    test_standard_complex_scaled_FFT_N();
    test_standard_complex_scaled_Both_sqrt_N();

    test_log_x_IFFT_N();
}
