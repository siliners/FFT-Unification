﻿/*
    Author: Thomas Kim
    Date: May 10, 2025
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
    - Share — copy and redistribute the material in any medium or format
    - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
    - Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
      You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others
    from doing anything the license permits.

    For full license text, see:
    https://creativecommons.org/licenses/by/4.0/legalcode
*/
#include <cpg/cpg_library.hpp>

#include "radix-s-fft.hpp"
using namespace fft_ifft;

void test_print_tuple()
{
    auto raw_tuple = 
        std::tuple{ 1.45, 1.3e-16, std::tuple{1, 2.0e-17, 3.4, std::vector{ 3.5e-16, 1.0/3 } } };

    std::cout << "==> raw tuple     : " << raw_tuple << std::endl;

    auto zero_adjusted = adjust_zero(raw_tuple);
    
    std::cout << "==> adjusted tuple: "<< zero_adjusted << std::endl;

    auto vctr_tpl = 
        std::vector{ std::tuple{1.5, 5, 4.5e-16, std::vector{ 3.4f, 5.6e-9f} },
                     std::tuple{7.5e-16, 12, 3.5, std::vector{ 4.4e-8f, 6.7f} } };
    
    std::cout << "vctr_tpl = " << vctr_tpl << std::endl;

}

void test_parameter_count_of_a_function()
{
    auto f0 = []()
        {
            return 2;
        };

    std::cout << "f0 takes " 
        << parameter_count_v<decltype(f0)>
            << " paramters. (WRONG: WATCH OUT)" 
            << std::endl << std::endl;

    auto f1 = [](auto a)
        {
            return a * 2;
        };

    std::cout << "f1 takes " 
        << parameter_count_v<decltype(f1)> 
            << " paramters." << std::endl;

    auto f2 = [](auto a, auto b)
        {
            return a * 2 + b;
        };

    std::cout << "f2 takes " 
        << parameter_count_v<decltype(f2)> 
        << " paramters." << std::endl;

    // INCORRECT 1: such functions are not useful
    // for our mathematical use
    auto f3 = [](auto... args) 
        {
            return (args + ... );
        };
    
    std::cout << "f3 takes " 
        << parameter_count_v<decltype(f3)> 
        << " paramters." << " (WRONG)\n" << std::endl;

    std::cout << "** Whenever you use parameter pack,"
        "\n\tyou should explicitly contrain it! **\n" << std::endl;

    // INCORRECT 2: such functions are not useful
    // for our mathematical use
    auto f4 = [](auto arg, auto... args) 
        {
            return (arg + ... + args);
        };
   
    std::cout << "f4 takes " 
        << parameter_count_v<decltype(f4)> 
        << " paramters." << " (WRONG)\n" << std::endl;

    std::cout << "** Whenever you use parameter pack,"
        "\n\tyou should explicitly contrain it! **\n" << std::endl;

    // CORRECT 1: such functions are integral cores of
    // our multivariate functions, args is constrained with requires
    auto f5 = [](auto... args) 
            requires ( sizeof...(args) == 5)
        {
            return (args * ... );
        };

    std::cout << "f5 takes " 
        << parameter_count_v<decltype(f5)> 
            << " paramters." << std::endl;

    // CORRECT 2: such functions are integral cores of
    // our multivariate functions
    // you have to provide total 5 parameters
    // to call this function, args is constrained with requires
    auto f6 = [](auto arg, auto... args) 
            requires ( sizeof...(args) == 2)
        {
            return (arg * ... * args);
        };

    std::cout << "f6 takes " 
        << parameter_count_v<decltype(f6)>
                << " paramters." << std::endl;

    // CORRECT 3: such functions are integral cores of
    // our multivariate functions
    // you have to provide total 5 parameters
    // to call this function, args is constrained with requires
    auto f7 = [](auto arg1, auto arg2, auto... args) 
            requires ( sizeof...(args) == 4)
        {
            return ((arg1 * arg2) * ... * args);
        };

    std::cout << "f7 takes " 
        << parameter_count_v<decltype(f7)>
                << " paramters." << std::endl;


    // CORRECT 4: but we will seldom use
    // functions with fixed parameter counts
    // internally in our implementation for advanced math.
    auto f8 = [](auto arg1, auto arg2, auto arg3)
        {
            return arg1 * arg2 * arg3;
        };

    std::cout << "f8 takes " 
        << parameter_count_v<decltype(f8)>
                << " paramters." << std::endl;
}

void test_fft_derivative_one()
{
    //        VarID = 0,      1,      2
    auto f1 = [](auto x, auto y, auto z)
    {
        return 1.0 * x + 2.0 * y + 3.0 * z;
    };

    // evaluate 1 order derivative 1
    // with respect to x or 0.
    //
    //           ∂𝑓₁
    // drv_f1 = ————
    //           ∂𝑥
    //
    // at this point drv_f1 is function
    auto drv_f1 = fft_derivative<0, 1>(f1);

    // we evaluate ∂𝑓₁ at (1.0, 1.0, 1.0)
    auto df1 = drv_f1(1.0, 1.0, 1.0);

    std::cout << "df1 = " << df1 << std::endl;

    //        VarID = 0,      1,      2,      3
    auto f2 = [](auto x, auto y, auto z, auto t)
    {
        return 1.0 * x + 2.0 * y + 3.0 * z + 4.0 * t;
    };

    // evaluate 1 order derivative 1
    // with respect to x or 0.
    //
    //           ∂𝑓₂
    // drv_f2 = ————
    //           ∂𝑧
    //
    // at this point drv_f2 is function
    auto drv_f2 = fft_derivative<2, 1>(f2);

    // we evaluate ∂𝑓₂/∂𝑥 at (1.0, 1.0, 1.0, 1.0)
    auto df2 = drv_f2(1.0, 1.0, 1.0, 1.0);

    std::cout << "df2 = " << df2 << std::endl;
}

void test_fft_derivative_two()
{
    auto precision = std::numeric_limits<double>::max_digits10;
    
    std::cout << "****** Precision = " << precision
     << " *********" <<std::endl << std::endl ;

    std::cout.precision(precision);

    auto args = std::array{ pi/6, pi/4, pi/3 };

             enum { _x,     _y,     _z };
    auto f = [](auto x, auto y, auto z)
    {
        return std::sin(x * y) * std::cos(z);
    };
    
    // evaluate 1st order derivative
    // with respect to x or _x.
    //
    //                ∂𝑓
    // drv<_x> * f = ————
    //                ∂𝑥
    //
    // at this point n_drv_f_x is function
    auto n_drv_f_x = drv<_x> * f;

    auto s_drv_f_x = [](auto x, auto y, auto z)
    {
        return y * std::cos(x * y) * std::cos(z);
    };

    std::cout << "n_drv_f_x" << args << " = " 
        << std::apply(n_drv_f_x, args) << std::endl;

    std::cout << "s_drv_f_x" << args << " = " 
        << std::apply(s_drv_f_x, args) << std::endl << std::endl;

    //
    //                          ∂²𝑓
    // drv<_y> * drv<_x> * f = ——————
    //                         ∂𝑦⋅∂𝑥
    //
    // at this point drv_f_yx is function
    auto n_drv_f_yx = drv<1, 1> * drv<0, 1> * f;

    auto s_drv_f_yx = [](auto x, auto y, auto z)
    {
        return ( std::cos(x * y) - x * y * std::sin(x * y) )
                 * std::cos(z);
    };

    std::cout << "n_drv_f_yx" << args << " = " 
        << std::apply(n_drv_f_yx, args) << std::endl;

    std::cout << "s_drv_f_yx" << args << " = " 
        << std::apply(s_drv_f_yx, args) << std::endl << std::endl;

    //
    //                                   ∂³𝑓
    // drv<_z> *drv<_y> * drv<_x> * f = ——————
    //                                  ∂𝑧⋅∂𝑦⋅∂𝑥
    //
    // at this point n_drv_f_zyx is function
    auto n_drv_f_zyx = drv<2, 1>*drv<1, 1>*drv<0, 1> * f;

    auto s_drv_f_zyx = [](auto x, auto y, auto z)
    {
        return -(std::cos(x*y) - x * y * std::sin(x * y) )
                 * std::sin(z);
    };

     std::cout << "n_drv_f_zyx" << args << " = " 
        << std::apply(n_drv_f_zyx, args) << std::endl;

    std::cout << "s_drv_f_zyx" << args << " = " 
        << std::apply(s_drv_f_zyx, args) << std::endl << std::endl;

}

void test_fft_derivative_three()
{
    auto precision = std::numeric_limits<double>::max_digits10;
    
    std::cout << "****** Precision = " << precision
     << " *********" <<std::endl << std::endl ;

    std::cout.precision(precision);

    auto args = std::array{ pi/6, pi/4, pi/3 };

             enum { _x,     _y,     _z };
    auto f = [](auto x, auto y, auto z)
    {
        return std::sin(x * y) * std::cos(z);
    };
    
    //                ∂𝑓
    // drv<_z> * f = ————
    //                ∂𝑧
    //
    // at this point n_drv_f_z is function
    auto n_drv_f_z = drv<_z> * f;

    auto s_drv_f_z = [](auto x, auto y, auto z)
    {
        return -std::sin(x * y) * std::sin(z);
    };

    std::cout << "n_drv_f_z" << args << " = " 
        << std::apply(n_drv_f_z, args) << std::endl;

    std::cout << "s_drv_f_z" << args << " = " 
        << std::apply(s_drv_f_z, args) << std::endl << std::endl;

    //
    //                  ∂²𝑓
    // drv<_z, 2> * f = ——————
    //                  ∂𝑧²
    //
    // at this point drv_f_z2 is function
    auto n_drv_f_z2 = drv<_z, 2> * f;

    auto s_drv_f_z2 = [](auto x, auto y, auto z)
    {
        return -std::sin(x * y) * std::cos(z);
    };

    std::cout << "n_drv_f_z2" << args << " = " 
        << std::apply(n_drv_f_z2, args) << std::endl;

    std::cout << "s_drv_f_z2" << args << " = " 
        << std::apply(s_drv_f_z2, args) << std::endl << std::endl;

    //
    //                   ∂³𝑓
    // drv<_z, 3> * f = ——————
    //                   ∂𝑧³
    //
    // at this point n_drv_f_z3 is function
    auto n_drv_f_z3 = drv<_z, 3> * f;

    auto s_drv_f_z3 = [](auto x, auto y, auto z)
    {
        return std::sin(x * y) * std::sin(z);
    };

     std::cout << "n_drv_f_z3" << args << " = " 
        << std::apply(n_drv_f_z3, args) << std::endl;

    std::cout << "s_drv_f_z3" << args << " = " 
        << std::apply(s_drv_f_z3, args) << std::endl << std::endl;

}

void test_gen_fft_ifft_N(int N)
{
    std::cout <<"==> Sampling N = " << N 
        << std::endl << std::endl;

    using enum fft_ifft::scaling_factor;

    cplx_numbers fvs(N);
    
    std::generate(fvs.begin(), fvs.end(),
        [x = 0.0]() mutable
        {
            return cplx((double)++x, 0.0);
        });

    std::cout <<"==>Input:  " << fvs << std::endl << std::endl;

    auto [fft, ifft] = get_gen_fft<IFFT_N>();
    
    std::cout <<"==> FFT Stage!\n"<<std::endl;
    fft(fvs);

    std::cout <<"\n==>FFTed:  " << fvs << std::endl << std::endl;

    std::cout <<"==> IFFT Stage!\n"<<std::endl;
    ifft(fvs);

    std::cout <<"\n==>IFFTed: " << fvs << std::endl << std::endl;

    std::cout << "-----------------------------------------------------" << std::endl;
}

void test_simple_fft_ifft(int N)
{
    std::cout <<"==> Sampling N = " << N 
        << std::endl << std::endl;

    using enum fft_ifft::scaling_factor;

    cplx_numbers fvs(N);
    
    std::generate(fvs.begin(), fvs.end(),
        [x = 0.0]() mutable
        {
            return cplx((double)++x, 0.0);
        });

    std::cout <<"==>Input:  " << fvs << std::endl << std::endl;

    auto [fft, ifft] = get_simple_fft<IFFT_N>();
    
    std::cout <<"==> FFT Stage!\n"<<std::endl;
    fft(fvs);

    std::cout <<"\n==>FFTed:  " << fvs << std::endl << std::endl;

    std::cout <<"==> IFFT Stage!\n"<<std::endl;
    ifft(fvs);

    std::cout <<"\n==>IFFTed: " << fvs << std::endl << std::endl;

    std::cout << "-----------------------------------------------------" << std::endl;
}

void test_gen_fft_ifft(int Sampling)
{
    Cpg_DisplayFunctionName();

    for(int N = 1; N <= Sampling; ++N)
    {
        test_gen_fft_ifft_N(N);
    }
}

void test_simplest_fft_ifft(int Sampling)
{
    Cpg_DisplayFunctionName();

    for(int N = 1; N <= Sampling; ++N)
    {
        test_simple_fft_ifft(N);
    }
}

int main()
{
    std::cout << std::boolalpha;

    // test_gen_fft_ifft(100);

    // test_simplest_fft_ifft(100);

    // test_print_tuple();
    // test_fft_derivative_one();

     test_fft_derivative_two();

    // test_fft_derivative_three();

    // test_parameter_count_of_a_function();
}