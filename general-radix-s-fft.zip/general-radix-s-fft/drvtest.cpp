﻿#include <cpg/cpg_library.hpp>

using namespace cpg_library;

void test_fft_derivative_two()
{
    auto precision = std::numeric_limits<double>::max_digits10;
    
    std::cout << "****** Precision = " << precision
     << " *********" <<std::endl << std::endl ;

    std::cout.precision(precision);

    auto args = std::array{ pi/6, pi/4, pi/3 };

             enum { _x,     _y,     _z };
    auto f = [](auto x, auto y, auto z)
    {
        return std::sin(x * y) * std::cos(z);
    };
    
    // evaluate 1st order derivative
    // with respect to x or _x.
    //
    //                ∂𝑓
    // drv<_x> * f = ————
    //                ∂𝑥
    //
    // at this point n_drv_f_x is function
    auto n_drv_f_x = drv7<_x, 1> * f;

    auto s_drv_f_x = [](auto x, auto y, auto z)
    {
        return y * std::cos(x * y) * std::cos(z);
    };

    std::cout << "n_drv_f_x" << args << " = " 
        << std::apply(n_drv_f_x, args) << std::endl;

    std::cout << "s_drv_f_x" << args << " = " 
        << std::apply(s_drv_f_x, args) << std::endl << std::endl;

    //
    //                          ∂²𝑓
    // drv<_y> * drv<_x> * f = ——————
    //                         ∂𝑦⋅∂𝑥
    //
    // at this point drv_f_yx is function
    auto n_drv_f_yx = drv7<_y, 1> * drv7<_x, 1> * f;

    auto s_drv_f_yx = [](auto x, auto y, auto z)
    {
        return ( std::cos(x * y) - x * y * std::sin(x * y) )
                 * std::cos(z);
    };

    std::cout << "n_drv_f_yx" << args << " = " 
        << std::apply(n_drv_f_yx, args) << std::endl;

    std::cout << "s_drv_f_yx" << args << " = " 
        << std::apply(s_drv_f_yx, args) << std::endl << std::endl;

    //
    //                                   ∂³𝑓
    // drv<_z> *drv<_y> * drv<_x> * f = ——————
    //                                  ∂𝑧⋅∂𝑦⋅∂𝑥
    //
    // at this point n_drv_f_zyx is function
    auto n_drv_f_zyx = drv7<_z, 1> * drv7<_y, 1> * drv7<_x, 1> * f;

    auto s_drv_f_zyx = [](auto x, auto y, auto z)
    {
        return -(std::cos(x*y) - x * y * std::sin(x * y) )
                 * std::sin(z);
    };

     std::cout << "n_drv_f_zyx" << args << " = " 
        << std::apply(n_drv_f_zyx, args) << std::endl;

    std::cout << "s_drv_f_zyx" << args << " = " 
        << std::apply(s_drv_f_zyx, args) << std::endl << std::endl;
}

void test_fft_derivative_three()
{
    auto precision = std::numeric_limits<double>::max_digits10;
    
    std::cout << "****** Precision = " << precision
     << " *********" <<std::endl << std::endl ;

    std::cout.precision(precision);

    auto args = std::array{ pi/6, pi/4, pi/3 };

             enum { _x,     _y,     _z };
    auto f = [](auto x, auto y, auto z)
    {
        return std::sin(x * y) * std::cos(z);
    };
    
    // evaluate 1st order derivative
    // with respect to x or _x.
    //
    //                ∂𝑓
    // drv<_x> * f = ————
    //                ∂𝑥
    //
    // at this point n_drv_f_x is function
    auto n_drv_f_x = d32<_x, 1> * f;

    auto s_drv_f_x = [](auto x, auto y, auto z)
    {
        return y * std::cos(x * y) * std::cos(z);
    };

    std::cout << "n_drv_f_x" << args << " = " 
        << std::apply(n_drv_f_x, args) << std::endl;

    std::cout << "s_drv_f_x" << args << " = " 
        << std::apply(s_drv_f_x, args) << std::endl << std::endl;

    //
    //                          ∂²𝑓
    // drv<_y> * drv<_x> * f = ——————
    //                         ∂𝑦⋅∂𝑥
    //
    // at this point drv_f_yx is function
    auto n_drv_f_yx = d32<_y, 1> * d32<_x, 1> * f;

    auto s_drv_f_yx = [](auto x, auto y, auto z)
    {
        return ( std::cos(x * y) - x * y * std::sin(x * y) )
                 * std::cos(z);
    };

    std::cout << "n_drv_f_yx" << args << " = " 
        << std::apply(n_drv_f_yx, args) << std::endl;

    std::cout << "s_drv_f_yx" << args << " = " 
        << std::apply(s_drv_f_yx, args) << std::endl << std::endl;

    //
    //                                   ∂³𝑓
    // drv<_z> *drv<_y> * drv<_x> * f = ——————
    //                                  ∂𝑧⋅∂𝑦⋅∂𝑥
    //
    // at this point n_drv_f_zyx is function
    auto n_drv_f_zyx = d32<_z, 1> * d32<_y, 1> * d32<_x, 1> * f;

    auto s_drv_f_zyx = [](auto x, auto y, auto z)
    {
        return -(std::cos(x*y) - x * y * std::sin(x * y) )
                 * std::sin(z);
    };

     std::cout << "n_drv_f_zyx" << args << " = " 
        << std::apply(n_drv_f_zyx, args) << std::endl;

    std::cout << "s_drv_f_zyx" << args << " = " 
        << std::apply(s_drv_f_zyx, args) << std::endl << std::endl;
}

int main()
{
    // test_fft_derivative_two();

    test_fft_derivative_three();
    
}