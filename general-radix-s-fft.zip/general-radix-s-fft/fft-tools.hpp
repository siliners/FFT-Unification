﻿/*
    Author: By Thomas Kim
    Date: April 18th 2025
    
    MSVC C++ compiler
    cl cpp-source.cpp /Fe: m.exe /std:c++latest /EHsc /nologo

    LLVM Clang
    clang++ -std=c++23 cpp-source.cpp  -o c.exe

    GNU G++
    g++ -std=c++23 cpp-source.cpp  -o g.exe

    Intel C++ compiler
    icx-cl cpp-source.cpp -o i.exe -Qstd=c++23 /EHsc /nologo
*/

#include <iostream>
#include <complex>
#include <cmath>
#include <numbers>
#include <vector>

namespace hidden
{
    template<typename=void>
    void display_compiler_info()
    {
        std::cout << "==> C++ Compiler: ";

        #if defined(GNU_GPP_COMPILER)
            std::cout << "GNU g++";
        #elif defined(__INTEL_LLVM_COMPILER)
            std::cout <<"Intel oneAPI icx-cl";
        #elif defined(__clang__)
            std::cout <<"LLVM clang++";
        #elif defined(__NVCC__)
            std::cout <<"CUDA C++ nvcc";
        #elif defined(_MSVC_LANG)
            std::cout <<"Microsoft C++ cl";
        #else
            std::cout <<"Unknown";
        #endif

        std::cout << "\n\n";
    }
}
// end of namespace hidden

#define Fft_Display(msg, func_name) \
    { std::cout << msg << func_name << std::endl; hidden::display_compiler_info(); }

#if defined(__FUNCTION_NAME__)
    #define DisplayFunctionName() Fft_Display("\n==> From Function: ", __FUNCTION_NAME__)
#elif defined(__PRETTY_FUNCTION__)
    #define DisplayFunctionName() Fft_Display("\n==> From Function: ", __PRETTY_FUNCTION__)
#elif defined(__FUNCSIG__)
    #define DisplayFunctionName() Fft_Display("\n==> From Function: ", __FUNCSIG__)
#else
    #define DisplayFunctionName()
#endif

namespace fft_ifft
{
    using cplx = std::complex<double>;
    using cplx_numbers = std::vector<cplx>;

    using call_counts = std::vector<int>;
    using call_ptr_counts = std::vector<int*>;

    using real_parts = std::vector<double>;

    template<typename Type>
    concept cplx_or_double_c = std::same_as<std::remove_cvref_t<Type>, cplx>
                || std::same_as<std::remove_cvref_t<Type>, double>;

    template<typename = void>
    double adjust_zero(double d)
    {
        constexpr auto epsilon = 
            std::numeric_limits<double>::epsilon() * 10000;

        return std::abs(d) < epsilon ? 0.0 : d; 
    }

    template<typename = void>
    cplx adjust_zero(const cplx& c)
    {
        return { adjust_zero(c.real()), adjust_zero(c.imag() )};
    }

    template<typename = void>
    auto cplx_to_double(const cplx_numbers& c)
    {
        real_parts r( c.size() );

        for(int n =0; n < c.size(); n++)
            r[n] = adjust_zero(c[n].real());

        return r;
    }

    template<typename Type = void>
    auto factorial(long long n)
    {
        if(n < 2) return 1LL;
        else
        {
            long long p = 1;

            for(long long k = 2; k <= n; ++k)
                p *= k;

            return p;
        }
    }
}
// end of namespace fft

namespace std
{
    template<typename Type>
    std::ostream& operator << ( std::ostream& os,
                const std::vector<std::complex<Type>>& c)
    {
        if (c.empty())
        {
            os <<"{ }"; return os;
        }
        else
        {
            os <<"{ ";

            for(int i = 0; i < c.size()-1; ++i)
                os << fft_ifft::adjust_zero(c[i]) <<", ";

            os << fft_ifft::adjust_zero(c.back()) << " }";

            return os;
        }
    }

    template<typename Type>
    std::ostream& operator << (std::ostream& os,
            const std::vector<Type>& c)
    {
        if (c.empty())
        {
            os <<"{ }"; return os;
        }
        else
        {
            os <<"{ ";

            for(int i = 0; i < c.size()-1; ++i)
                os << c[i] <<", ";

            os << c.back() << " }";

            return os;
        }
    }
}
//end of namespace std

namespace fft_ifft
{
    template<typename Type = void>
    int reverse_bits(int x, int numBits)
    {
        int reversed = 0; // N = 16, numBits = log2(16) = 4

        // i = 0, 1, 2, 3
        for(int i = 0; i < numBits; ++i)
        {
            if(x & (1 << i))
            {
                reversed |= 1 << (numBits-1 - i); 
            }
        }

        return reversed;
    }

    /*
        using cplx = std::complex<double>;
        using cplx_numbers = std::vector<cplx>;
    */
    template<typename Type = void>
    void shuffle_coefficients(cplx_numbers& data)
    {
        int N = data.size(); // 1, 2, 4, 8, 16, ... 2^n, n = 0, 1, 2, 3

        // N = 16, numBits = 4
        int numBits = log2(N); // N = 16, log2(16) = log2(2^4) = 4 log2(2) = 4;

        for(int x = 0; x < N; ++x)
        {
            int reverse_index = reverse_bits(x, numBits);

            if(reverse_index > x)
            {
                std::swap(data[x], data[reverse_index]);
            }
        }
    }

    template<typename Type = void>
    void fft_loop(cplx_numbers& coeffs, bool postive = true)
    {
        constexpr auto pi = std::numbers::pi_v<double>;

        int N = coeffs.size();

        cplx_numbers power(N);

        for(int n = 0; n < N/2; ++n)
            power[n]= postive ? std::exp( cplx{ 0.0, 2 * pi * n / N } ) : 
                std::exp( cplx{ 0.0, -2 * pi * n / N } );

        shuffle_coefficients(coeffs);

        for(int len = 2; len <= N; len *= 2 )
        {
            for(int i = 0;  i < N; i += len)
            {
                for(int j = 0; j < len/2; ++j)
                {
                    auto left_even = coeffs[i+j];
                    auto right_odd  = coeffs[i+j + len/2];
                    
                    // auto w = postive ? std::exp( cplx{ 0.0, 2 * pi * j / len} ) : 
                    //         std::exp( cplx{ 0.0, -2 * pi * j / len} );
                    auto w = power[j * (N/len)];

                    coeffs[i+j] = left_even + w * right_odd;
                    coeffs[len/2 + i+j] = left_even - w * right_odd;
                }
            }
        }
    }

    enum class scaling_factor { NO_Scaling, FFT_N, IFFT_N, Both_sqrt_N };

    template<scaling_factor factor>
    auto get_fft_ifft()
    {
        if constexpr(factor == scaling_factor::NO_Scaling)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::FFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, false); // e^-2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, true); // e^2pi i /N
            };

            return std::tuple{ fft, ifft };
        }
        else if constexpr(factor == scaling_factor::IFFT_N)
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, false); // e^-2pi i /N
            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, true); // e^2pi i /N

                double N = coeffs.size();

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
        else // factor == scaling_factor::Both_sqrt_N
        {
            auto fft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, false); // e^-2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;

            };

            auto ifft = [](cplx_numbers& coeffs)
            {
                fft_loop(coeffs, true); // e^2pi i /N

                double N = std::sqrt(coeffs.size());

                for(int i = 0; i < coeffs.size(); ++i)
                    coeffs[i] /= N;
            };

            return std::tuple{ fft, ifft };
        }
    }
    // end of function fft_ifft()

    template<typename ArgType>
    auto cplx_to_polar(const std::complex<ArgType>& c)
    {
        return std::tuple{ std::abs(c), std::arg(c) };
    }

    enum class sampling_method
    {
        standard_sampling,
        rotated_sampling,
        rotated_half_N_sampling,
        radius_sampling,
        radius_sampling_x_1,
        radius_rotated_sampling,
        complex_scaled_sampling,
        non_zero_centered_sampling,
        laurent_series_sampling,
        fourier_series_sampling,
    };

    template<typename = void>
    auto get_omega(int N)
    {
        return [ N ](auto k)
        {
            constexpr auto pi = std::numbers::pi_v<double>;
            return std::exp(cplx{0.0, 2.0 * pi * k / N });
        };
    }

    template<typename = void>
    auto get_rotated_omega(int N, auto theta)
    {
        auto w = get_omega(N);

        constexpr auto pi = std::numbers::pi_v<double>;
        auto s = std::exp(cplx{0.0, pi / N });

        return std::tuple{s, w};
    }

    template<typename = void>
    auto get_radius_omega(int N, double radius)
    {
        auto w = get_omega(N);
        auto rho = std::pow(radius, 1.0/N);
        
        return std::tuple{rho, w};
    }

    template<typename = void>
    auto get_radius_rotated_omega(int N, double radius, double angle)
    {
        auto w = get_omega(N);

        auto c = std::polar(radius/N, angle/N);
        
        return std::tuple{ c, w };
    }

    template<typename = void>
    auto get_complex_scaled_omega(int N, std::complex<double> const& c)
    {
        auto w = get_omega(N);

        auto rho_s = std::pow(c, 1.0/N);
        
        return std::tuple{rho_s, w};
    }

    template<cplx_or_double_c EleType>
    auto reverse(std::vector<EleType> const& fn)
    {
        auto an = fn;
        std::reverse(an.begin(), an.end());
        return an;
    }

    template<cplx_or_double_c EleType>
    void reverse_inplace(std::vector<EleType>& fn)
    {
        std::reverse(fn.begin(), fn.end());
    }

    template<sampling_method method,
        scaling_factor factor = scaling_factor::IFFT_N>
    auto get_taylor_sampler()
    {
        if constexpr(method == sampling_method::standard_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    auto w = get_omega(N);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + w(k) ) / (double)N;
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                return std::tuple{ sampler, fft, ifft };
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    auto w = get_omega(N);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                return std::tuple{ sampler, fft, ifft };
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    auto w = get_omega(N);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                return std::tuple{ sampler, fft, ifft };
            }
        }
        else if constexpr(method == sampling_method::rotated_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) ) / (double)N;
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 1; k < N; ++k)
                        an[k] /= std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 1; k < N; ++k)
                        an[k] /= std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 1; k < N; ++k)
                        an[k] /= std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
        }
        else if constexpr(method == sampling_method::rotated_half_N_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) ) / (double)(N/2);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 1; k < N; ++k)
                        an[k] /= std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 0; k < N; ++k)
                        an[k] = (an[k] * 2.0) / std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + s * w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv)
                {
                    auto N = fv.size();
                    auto an = fv;

                    constexpr auto pi = std::numbers::pi_v<double>;
                    auto [s, w] = get_rotated_omega(N, pi);

                    for(int k = 0; k < N; ++k)
                        an[k] = (an[k] * 2.0) / std::pow(s, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
        }
        else if constexpr(method == sampling_method::radius_sampling_x_1)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + rho * w(k) ) / (double)(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft]<cplx_or_double_c CenterType = double>
                    (const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    auto radius_1 = 1.0 - radius;

                    for(int k = 0; k < N; ++k)
                        an[k] *= radius_1 / std::pow(rho, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + rho * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    auto radius_1 = 1.0 - radius;

                    for(int k = 0; k < N; ++k)
                        an[k] *= radius_1 / std::pow(rho, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + rho * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    auto radius_1 = 1.0 - radius;

                    for(int k = 0; k < N; ++k)
                        an[k] *= radius_1 / (std::pow(rho, k) * (double)std::sqrt(N));

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }

        }
        else if constexpr(method == sampling_method::radius_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + rho * w(k) ) / (double)(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(rho, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + rho * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft]<cplx_or_double_c CenterType = double>
                    (const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(rho, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [rho, w] = get_radius_omega(N, radius);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = 
                            f( center + rho * w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [rho, w] = get_radius_omega(N, radius);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(rho, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
        }
        else if constexpr(method == sampling_method::radius_rotated_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, double angle, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);
                        
                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + c * w(k) ) / (double)(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius, double angle)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(c, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, double angle, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + c * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius, double angle)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(c, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, double radius, double angle, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = 
                            f( center + c * w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, double radius, double angle)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [c, w] = get_radius_rotated_omega(N, radius, angle);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(c, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
        }
        else if constexpr(method == sampling_method::complex_scaled_sampling)
        {
            if constexpr(factor == scaling_factor::IFFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, std::complex<double> const& c, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [cN, w] = get_complex_scaled_omega(N, c);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + cN * w(k) ) / (double)(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, std::complex<double> const& c)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [cN, w] = get_complex_scaled_omega(N, c);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(cN, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::FFT_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, std::complex<double> const& c, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [cN, w] = get_complex_scaled_omega(N, c);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = f( center + cN * w(k) );
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, std::complex<double> const& c)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [cN, w] = get_complex_scaled_omega(N, c);

                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(cN, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
            else if constexpr(factor == scaling_factor::Both_sqrt_N)
            {
                auto sampler = []<cplx_or_double_c CenterType = double>
                    (auto f, auto N, std::complex<double> const& c, CenterType center = 0)
                {
                    constexpr auto pi = std::numbers::pi_v<double>;
                                        
                    auto [cN, w] = get_complex_scaled_omega(N, c);

                    std::vector<cplx> function_values(N);

                    for(int k = 0; k < (int)N; ++k)
                    {
                        function_values[k] = 
                            f( center + cN * w(k) ) / (double)std::sqrt(N);
                    }

                    return function_values;
                };

                auto [fft, ifft] = get_fft_ifft<factor>();

                auto reconstructor = [ifft](const auto& fv, std::complex<double> const& c)
                {
                    auto N = fv.size();
                    auto an = fv;

                    auto [cN, w] = get_complex_scaled_omega(N, c);
                    
                    for(int k = 0; k < N; ++k)
                        an[k] /= std::pow(cN, k);

                    return an;
                };

                return std::tuple{ sampler, reconstructor, fft, ifft};
            }
        }
    }
    // end of function get_taylor_sampler()

    template<scaling_factor factor = scaling_factor::IFFT_N>
    auto get_laurent_sampler()
    {
        if constexpr(factor == scaling_factor::IFFT_N)
        {
            auto sampler = []<cplx_or_double_c CenterType = double>
                (auto f, auto N, int pole = 0, CenterType center = 0)
            {
                auto w = get_omega(N);

                std::vector<cplx> function_values(N);

                for(int k = 0; k < (int)N; ++k)
                {
                    function_values[k] = w(pole) * f( center + w(k) ) / (double)N;
                }

                return function_values;
            };

            auto reconstructor = [](const auto& fv)
            {
                return fv;
            };

            auto [fft, ifft] = get_fft_ifft<factor>();

            return std::tuple{ sampler, reconstructor, fft, ifft };
        }
        else if constexpr(factor == scaling_factor::FFT_N)
        {
            auto sampler = []<cplx_or_double_c CenterType = double>
                (auto f, auto N, int pole, CenterType center = 0)
            {
                auto w = get_omega(N);

                std::vector<cplx> function_values(N);

                for(int k = 0; k < (int)N; ++k)
                {
                    function_values[k] = w(k*pole) * f( center + w(k) );
                }

                return function_values;
            };

            auto reconstructor = [](const auto& fv)
            {
                return fv;
            };

            auto [fft, ifft] = get_fft_ifft<factor>();

            return std::tuple{ sampler, reconstructor, fft, ifft };
        }
        else if constexpr(factor == scaling_factor::Both_sqrt_N)
        {
            auto sampler = []<cplx_or_double_c CenterType = double>
                (auto f, auto N, int pole, CenterType center = 0)
            {
                auto w = get_omega(N);

                std::vector<cplx> function_values(N);

                for(int k = 0; k < (int)N; ++k)
                {
                    function_values[k] = w(k * pole) *
                            f( center + w(k) ) / (double)std::sqrt(N);
                }

                return function_values;
            };

            auto reconstructor = [](const auto& fv)
            {
                return fv;
            };

            auto [fft, ifft] = get_fft_ifft<factor>();

            return std::tuple{ sampler, reconstructor, fft, ifft };
        }
    }
    // end of function get_laurent_sampler()

    template<scaling_factor factor = scaling_factor::IFFT_N>
    auto get_essential_singularity_sampler()
    {
        auto [sampler, recon, fft, ifft]
            = get_laurent_sampler<factor>();

        auto reconstructor = [](const auto& fv)
        {
            // return fv;
            return reverse(fv);
        };

        return std::tuple{ sampler, reconstructor, fft, ifft };
    }
    // end of function get_essential_singularity_sampler()
}
// end of namespace fft
